$(document).ready(function() {
  $('.nav-button').click(function() {
    $('.nav-button').toggleClass('change');
  });
  $(window).scroll(function() {
    let position = $(this).scrollTop();
    if(position >= 100) {
      $('.nav-menu').addClass('custom-navbar');
    } else {
      $('.nav-menu').removeClass('custom-navbar');
    }
  });
  $(window).scroll(function() {
    let position = $(this).scrollTop();
    if(position >= 580) {
      $('.nav-menu').addClass('custom-navbar3');
    } else {
      $('.nav-menu').removeClass('custom-navbar3');
    }
  });



});

(function($) {
  "use strict"; // Start of use strict

  // Smooth scrolling using jQuery easing
  $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: (target.offset().top - 72)
        }, 1000, "easeInOutExpo");
        return false;
      }
    }
  });

  })(jQuery);



  var wow = new WOW({
   //disabled for mobile
     mobile: false
 });

 wow.init();

 $(".card").click(function(e){
  $(e.currentTarget).toggleClass("flip");
});


$(document).ready(function(){
    $('.customer-logos').slick({
        slidesToShow: 7,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 100,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
});
